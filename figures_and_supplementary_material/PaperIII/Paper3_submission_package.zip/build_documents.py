from pathlib import Path
from docx import Document
from docx.oxml import OxmlElement
from docx.text.paragraph import Paragraph
from zipfile import ZipFile,ZIP_DEFLATED
from lxml import etree
import shutil,json
O=Path('deliverables/PAPER3_SUBMISSION');d=Document('upload/Paper3_manuscript(1).docx')
def replace(p,t):p.text=t
for p in d.paragraphs:
 p.text=p.text.replace('Fig. S2','Fig. S1').replace('Fig. 1D–E','Fig. 1E').replace('Fig. S4','Fig. S2') if p.text else p.text
# Preserve images: blank paragraph p.text assignment above destroys pictures! reload and only replace nonempty paragraphs.
d=Document('upload/Paper3_manuscript(1).docx')
for p in d.paragraphs:
 if p.text:p.text=p.text.replace('Fig. S2','Fig. S1').replace('Fig. 1D–E','Fig. 1E').replace('Fig. S4','Fig. S2')
for p in d.paragraphs:
 if p.text.startswith('The joint model reduced'):p.text='The joint model reduced prediction error on unseen PDB entries by 3.24%, with a conditional bootstrap interval excluding zero (Fig. 1E). A joint model with only 24 Fourier coefficients achieved lower validation error than any tested additive model, including models with up to 160 coefficients (Fig. 1F). The joint-minus-additive map identifies a reproducible predictive contribution beyond the selected separate torsional effects.'
 if p.text.startswith('Predictive gain varied'):p.text+=' The largest regional gains occurred in the Other remainder and Positive φ band (Fig. 1G); these gains measure predictive improvement, not the sign of the coupling map.'
 if p.text.startswith('To test whether the joint dependence observed'):p.text=p.text.replace('To test whether the joint dependence observed in overall statistical above reflects intrinsic peptide mechanics or external environmental forces,','To test whether an isolated peptide potential can generate joint geometric dependence,')
 if p.text.startswith('Coupling requires interactions'):p.text='We tested the sensitivity of the peptide contrast to selected nonbonded repulsion by reducing the r⁻¹² term for 15 ordinary heavy-atom pairs. Their attraction, hydrogen-involving interactions, and force-field exceptions were preserved. Removing 75% of this selected repulsion approximately halved the α contrast, slightly increased the β contrast, and reversed the PPII contrast’s sign (Fig. 2D). Complete-removal contrasts were withheld because three endpoints failed numerical quality control (Fig. S1).'
 if p.text=='The isolated peptide reproduces φ×ψ coupling, partly through steric repulsion':p.text='The isolated peptide generates coupling sensitive to selected repulsion'
 if p.text.startswith('For each PDB, squared errors'):p.text+=' Global gain and its interval use the unified Figure 1 summary and paired test-PDB gain table throughout. Fourier coefficient counts exclude the separately fitted intercept; ridge regularization means these counts are nominal rather than effective degrees of freedom. The five disjoint regions are αR core, φ ∈ [−75°, −45°), ψ ∈ [−60°, −20°); αR outer, [−90°, −30°) × [−80°, 20°) excluding the core; β box, φ ∈ [−180°, −90°), ψ ∈ [90°, 180°) or [−180°, −150°); Positive φ, φ ∈ [60°, 110°) at any ψ; and Other, all remaining observations.'
 if p.text.startswith('Additional paired-environment'):pass
# Replace discussion with concise accepted text.
ps=d.paragraphs;start=next(i for i,p in enumerate(ps) if p.text=='Discussion');end=next(i for i,p in enumerate(ps) if p.text=='Limitations')
anchor=ps[start]
for p in ps[start+1:end]:p._element.getparent().remove(p._element)
texts=[
'The isolated ff14SB peptide produces φ/ψ coupling but fails to reproduce the sampling-matched protein pattern: its α contrast has the opposite sign, and its PPII contrast is much smaller. The α discrepancy (−0.15°) exceeds the matched model contrast (+0.08°). Both resolved residuals are negative, although their shared direction does not establish a shared cause.',
'Conformation-dependent geometry is well established (Karplus, 1996; Berkholz et al., 2009). Our contribution is a comparison under matched conformational sampling. Matching reverses the model’s PPII contrast but leaves the α and PPII discrepancies, showing why representative conformations alone are insufficient.',
'These discrepancies could reflect the tested potential rather than an essential role for protein context. Local quantum-mechanical models reproduce protein geometry trends (Improta et al., 2015), and Jiang et al. (2018) reported a transition-region O···C distance error in FF99SB that quantum calculations avoided. Solvent, electronic interactions, ensemble averaging, and protein contacts remain additional explanations. Testing alternative models at the same sampled conformations would distinguish their contributions.',
'The protein reference also reflects refinement restraints. The conformation-dependent library adopted as the Phenix default was derived from protein structures (Berkholz et al., 2009; Moriarty et al., 2016), and PHENIX-labelled structures showed more negative residuals than REFMAC-labelled structures. This descriptive difference cannot isolate a restraint effect; controlled re-refinement of identical diffraction data would provide a direct test.',
'The matched contrasts provide a quantitative benchmark for alternative peptide models. Combining model comparisons with controlled refinement would clarify how much of the protein pattern local physics reproduces and what remains dependent on protein context.'
]
for t in texts:
 el=OxmlElement('w:p');anchor._p.addnext(el);anchor=Paragraph(el,anchor._parent);anchor.text=t
for p in d.paragraphs:
 if p.text.startswith('Figure 1.'):p.text='Figure 1. Conformation-dependent backbone geometry and held-out prediction. A, Backbone geometry schematic. B, Atlas and PDB partition. C, Mean τ and density contours. D1–D3, Additive, joint, and joint-minus-additive maps on common supported cells. D3 uses a ±2° color scale; open circles mark saturated cells and colorbar extensions indicate clipping. E, Paired per-PDB additive-minus-joint MSE distribution; positive values favor the joint model. The orange line marks the equal-PDB mean gain, 0.1061 deg² (3.24%), and shading marks its conditional 95% bootstrap interval, 0.0991–0.1132 deg². The interval describes uncertainty in the mean, not between-PDB variation. F, Validation MSE versus Fourier coefficient count, excluding the intercept; each point uses the lowest validation error among tested ridge penalties. Joint K = 2 has 24 coefficients and validation MSE 3.215 deg² versus 3.227 deg² for the best additive fit. G and H, Regional and residue-group gains with conditional 95% PDB-bootstrap intervals.'
 if p.text.startswith('The accompanying analysis package'):p.text='The accompanying supporting archive contains numerical return records, model and matching definitions, per-PDB means, figure-generating code, summary tables, and input hashes. The primary atlas is identified by its filename and SHA-256 checksum in Methods. Public deposition details must be supplied with the final submission.'
ref=next(p for p in d.paragraphs if p.text=='Figure captions');r=ref.insert_paragraph_before('Jiang Z, Biczysko M, Moriarty NW. Accurate geometries for “Mountain pass” regions of the Ramachandran plot using quantum chemical calculations. Proteins. 2018;86:273–278. doi:10.1002/prot.25451.')
main=O/'Paper3_manuscript.docx';d.save(main)
# Supplement: retain reproducible current data; omit duplicate and historical inverse checks.
s=Document('deliverables/PAPER3_THREE_FIGURE_REVISION/Paper3_supplement.docx')
ps=s.paragraphs;remove=[]
a=next(i for i,p in enumerate(ps) if p.text=='Historical inverse prediction checks');b=next(i for i,p in enumerate(ps) if p.text=='Additional mechanism branches');remove+=ps[a:b]
for begin,endtext in [('Figure S1  Held out gain companion','Figure S2  Numerical precision and interpolation checks'),('Figure S3  Separate historical screen and inverse prediction results','Figure S4  Recovered paired environment summaries')]:
 a=next(i for i,p in enumerate(ps) if p.text==begin);b=next(i for i,p in enumerate(ps) if p.text==endtext);remove+=ps[a:b]
for p in remove:
 if p._element.getparent() is not None:p._element.getparent().remove(p._element)
for p in s.paragraphs:
 if p.text:p.text=p.text.replace('Fig. S4','Fig. S2').replace('Figure S2  Numerical','Figure S1  Numerical').replace('Figure S4  Recovered paired','Figure S2  Paired')
si=O/'Paper3_supplement.docx';s.save(si)
def images(p,names):
 with ZipFile(p) as z:dat={n:z.read(n) for n in z.namelist()}
 r=etree.fromstring(dat['word/document.xml']);rels=etree.fromstring(dat['word/_rels/document.xml.rels']);targets={e.get('Id'):e.get('Target') for e in rels};ids=r.xpath('//a:blip/@r:embed',namespaces={'a':'http://schemas.openxmlformats.org/drawingml/2006/main','r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'});assert len(ids)==len(names),(len(ids),names)
 for rid,name in zip(ids,names):dat['word/'+targets[rid]]=(O/'figures'/f'{name}.png').read_bytes()
 with ZipFile(p,'w',ZIP_DEFLATED) as z:
  for n,b in dat.items():z.writestr(n,b)
images(main,['Figure_1_atlas','Figure_2_local_model','Figure_3_matched_gap']);images(si,['Figure_S1_numerical_QC','Figure_S2_paired_environment'])
(O/'FINAL_SUBMISSION_CHECKLIST.md').write_text('# Final submission details\n\nThe scientific draft and figures are prepared. Before uploading to a journal, supply and verify:\n\n- Author list, affiliations and corresponding-author details.\n- Funding, competing interests and author contributions.\n- Target-journal formatting and required declarations.\n- A public supporting-data/code accession or an agreed journal deposit route. The package does not contain the full 1.6-million-row atlas; its filename/hash and aggregate results are provided.\n\nNo second-model result is claimed. Historical G4/G5B checks remain in source records and are omitted from submission SI because sealed standalone definitions were unavailable.\n')
print(main,si)
