# Final submission details

The scientific draft and figures are prepared. Before uploading to a journal, supply and verify:

- Author list, affiliations and corresponding-author details.
- Funding, competing interests and author contributions.
- Target-journal formatting and required declarations.
- A public supporting-data/code accession or an agreed journal deposit route. The package does not contain the full 1.6-million-row atlas; its filename/hash and aggregate results are provided.

No second-model result is claimed. Historical G4/G5B checks remain in source records and are omitted from submission SI because sealed standalone definitions were unavailable.
