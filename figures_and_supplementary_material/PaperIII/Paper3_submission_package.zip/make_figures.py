from pathlib import Path
import zipfile,json,io
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parents[2];O=Path(__file__).parent/'figures';D=Path(__file__).parent/'source_data'
plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','pdf.fonttype':42})
cols=['#0072B2','#D55E00','#009E73'];regs=['alpha','beta','ppii'];labs=['α','β','PPII']
def zj(stamp,name):
 with zipfile.ZipFile(next(D.glob('*'+stamp+'*.zip'))) as z:return json.loads(z.read(name))
def zcsv(stamp,name):
 with zipfile.ZipFile(next(D.glob('*'+stamp+'*.zip'))) as z:return pd.read_csv(io.BytesIO(z.read(name)))
def read(n):return json.loads((D/n).read_text())
def label(a,l,t):a.set_title(l+'  '+t,loc='left',fontweight='bold',fontsize=10,pad=10)
def save(f,n,note):
 f.text(.03,.012,note,fontsize=8);f.tight_layout(rect=(0,.045,1,.97))
 for ext in ['png','pdf','svg']:f.savefig(O/(n+'.'+ext),dpi=240,bbox_inches='tight')
 plt.close(f)
def txt(a,s):a.axis('off');a.text(.02,.87,s,transform=a.transAxes,va='top',linespacing=1.7,fontsize=11)

from matplotlib.patches import Arc, FancyBboxPatch, Rectangle
def line(a,p,q,c='#333',lw=2):a.plot([p[0],q[0]],[p[1],q[1]],c=c,lw=lw,solid_capstyle='round')
def atom(a,p,t,c='#222',size=12):a.text(*p,t,ha='center',va='center',fontsize=size,color=c,bbox=dict(fc='white',ec='none',pad=1))
def peptide(a,capped=False):
 a.axis('off');a.set(xlim=(-.3,6.4),ylim=(-1.4,3.4))
 ps=[(0,1.7),(1,.9),(2,1.7),(3,.9),(4,1.7),(5,.9),(6,1.7)]
 for x,y in zip(ps,ps[1:]):line(a,x,y)
 for x in [ps[1],ps[5]]:
  line(a,(x[0]-.07,x[1]-.15),(x[0]-.07,x[1]-.85));line(a,(x[0]+.07,x[1]-.15),(x[0]+.07,x[1]-.85));atom(a,(x[0],x[1]-1.05),'O','#D55E00')
 for i,t in enumerate(['CH₃' if capped else 'Cαᵢ₋₁','C','N','Cα','C','N','CH₃' if capped else 'Cαᵢ₊₁']):atom(a,ps[i],t,'#0072B2' if t=='N' else '#222')
 # Correct central carbonyl: C at index 4, O above it
 line(a,(3.93,1.9),(3.93,2.65));line(a,(4.07,1.9),(4.07,2.65));atom(a,(4,2.9),'O','#D55E00')
 # index 5 is N: erase the provisional carbonyl there
 a.add_patch(Rectangle((4.7,-.3),.65,1.05,fc='white',ec='none',zorder=3))
 line(a,(3,.7),(3,-.1));atom(a,(3,-.35),'CH₃' if capped else 'Cβ',size=11)
 a.add_patch(Arc((3,.9),1.0,1.0,theta1=39,theta2=141,color='#009E73',lw=2));atom(a,(3,1.5),'τ','#009E73')
 a.text(2.5,2.15,'φ',color='#0072B2',fontsize=13,ha='center');a.text(3.55,1.8,'ψ',color='#D55E00',fontsize=13,ha='center');a.text(1.5,1.72,'ω',fontsize=12,ha='center')
 if capped:a.text(.5,3.18,'ACE',ha='center',fontsize=10);a.text(3,3.18,'ALA',ha='center',fontsize=10);a.text(5.5,3.18,'NME',ha='center',fontsize=10)
 a.text(3,-1.0,'Schematic projection; φ and ψ are torsions',ha='center',fontsize=8)
def flow(a):
 a.axis('off');a.set(xlim=(0,10),ylim=(0,10))
 for y,text in [(8.4,'PISCES selection  •  resolution ≤2.0 Å'),(6.6,'Chain audit and coordinate quality filters'),(4.8,'1,636,322 residues  •  7,938 PDB entries')]:
  a.add_patch(FancyBboxPatch((.3,y-.55),9.4,1.1,boxstyle='round,pad=.12',fc='#EDF4F7',ec='#8AA5B5'));a.text(5,y,text,ha='center',va='center',fontsize=9)
 for y in [7.7,5.9]:a.annotate('',xy=(5,y-.45),xytext=(5,y+.1),arrowprops=dict(arrowstyle='->',color='#555'))
 for x,t,c in [(1.7,'Training\n60%\n4,762 PDBs',cols[0]),(5,'Validation\n20%\n1,588 PDBs',cols[1]),(8.3,'Test\n20%\n1,588 PDBs',cols[2])]:
  a.annotate('',xy=(x,2.75),xytext=(5,4.15),arrowprops=dict(arrowstyle='->',color='#777'));a.add_patch(FancyBboxPatch((x-1.35,1),2.7,1.7,boxstyle='round,pad=.1',fc='white',ec=c));a.text(x,1.85,t,ha='center',va='center',fontsize=9,color=c)
 a.text(5,.3,'Split by PDB entry',ha='center',fontsize=9)
def match_design(a):
 a.set(xlim=(-19,19),ylim=(-19,19),xlabel='Δφ from region center (°)',ylabel='Δψ from region center (°)')
 for x in [-10,10]:
  for y in [-10,10]:
   a.add_patch(Rectangle((x-5,y-5),10,10,ec='#0072B2',fc='#EDF4F7',lw=1))
   xx,yy=np.meshgrid(np.linspace(x-5,x+5,5),np.linspace(y-5,y+5,5));a.scatter(xx,yy,s=9,c='#aaa',marker='+')
   # illustrative residue positions, not observations
   a.scatter([x-1.8,x+.8,x+2],[y+1.7,y-.7,y+2.3],s=17,c='#D55E00')
 a.set_xticks([-10,0,10]);a.set_yticks([-10,0,10]);a.text(.5,.97,'±5° windows; 5 × 5 grids',transform=a.transAxes,ha='center',va='top',fontsize=8)
 a.text(.5,-.30,'Illustrative observations → interpolate τ\nMean within PDB → equal-PDB mean → contrast',transform=a.transAxes,ha='center',fontsize=8)

p=read('TAU_PRECISION_RETURN_MANIFEST.json');rp=read('TAU_REPULSION_RETURN_MANIFEST.json');ma=read('MATCHED_SAMPLING_RETURN_MANIFEST.json')
# Figure 1 with directly regenerated maps and shared absolute scale.
m=zcsv('182254','maps.csv');sg=zcsv('182254','subgroups.csv');summary=zj('182254','SUMMARY.json');t= pd.read_csv(D/'RETURN_TO_CHAT_1_tuning.csv')
f,ax=plt.subplots(4,3,figsize=(13,15));a=ax.ravel()
peptide(a[0]);label(a[0],'A','Measured geometry')
flow(a[1]);label(a[1],'B','Cohort and partition')
def mapplot(a,key,title,vmin=None,vmax=None):
 v=m.copy();v.loc[~v.supported,key]=np.nan;mat=v.pivot(index='psi',columns='phi',values=key)
 im=a.imshow(mat.values,origin='lower',extent=(-180,180,-180,180),cmap='RdBu_r' if key=='difference' else 'viridis',vmin=vmin,vmax=vmax,aspect='equal');a.set_xlabel('φ (°)');a.set_ylabel('ψ (°)');f.colorbar(im,ax=a,shrink=.75,extend='both' if key=='difference' else 'neither',label='Δτ (°)' if key=='difference' else 'τ (°)');a.set_title(title,loc='left',fontsize=10,fontweight='bold')
 if key=='difference':
  sat=v[v.supported & (v[key].abs()>2)];a.scatter(sat.phi,sat.psi,s=12,facecolors='none',edgecolors='black',linewidths=.5)
mapplot(a[2],'mean_tau','C  Observed mean τ');den=m.pivot(index='psi',columns='phi',values='train_n');a[2].contour(np.arange(-175,180,10),np.arange(-175,180,10),np.log1p(den.values),levels=4,colors='white',linewidths=.5)
lo=min(m.loc[m.supported,'additive'].min(),m.loc[m.supported,'joint'].min());hi=max(m.loc[m.supported,'additive'].max(),m.loc[m.supported,'joint'].max())
mapplot(a[3],'additive','D1  Additive fit',lo,hi);mapplot(a[4],'joint','D2  Joint fit',lo,hi);lim=2.0;mapplot(a[5],'difference','D3  Joint − additive',-lim,lim)
for model,col in zip(['additive','joint'],cols):
 q=t[t.model==model].groupby('harmonics').validation_structure_mse.min();a[8].plot(4*q.index+ (4*q.index**2 if model=='joint' else 0),q.values,'o-',color=col,label=model)
a[8].legend();a[8].set_xlabel('Number of Fourier coefficients');a[8].set_ylabel('Validation MSE (deg²)');label(a[8],'F','Tested model flexibility')
for axis,category,letter in [(a[9],'region','G'),(a[10],'residue','H')]:
 q=sg[sg.category==category]
 if len(q)==0:q=sg[sg.category!='region']
 x=np.arange(len(q));axis.errorbar(x,q.gain_deg2,yerr=[q.gain_deg2-q.gain_deg2_lo,q.gain_deg2_hi-q.gain_deg2],fmt='o',capsize=3);axis.axhline(0,c='k',lw=.8);axis.set_xticks(x,[{'alphaR_core':'αR core','alphaR_outer':'αR outer','beta_box':'β box','other':'Other','positive_phi_band':'Positive φ','GLY':'Gly','ILE_VAL':'Ile/Val','OTHER':'Other','PRO':'Pro'}.get(z,z) for z in q.label],rotation=30,ha='right');axis.set_ylabel('Held-out MSE gain (deg²)');label(axis,letter,'Regional gain' if category=='region' else 'Residue-group gain')
from matplotlib.gridspec import GridSpec
pos=a[6].get_position();a[6].remove();a[7].remove();gs=ax[0,0].get_gridspec();h=f.add_subplot(gs[2,:2]);pg=zcsv('182254','test_PDB_gain.csv');v=summary['heldout_gain_deg2'];low,high=summary['conditional_PDB_bootstrap_95CI']
h.hist(pg.gain,bins=50,color=cols[0],alpha=.75);h.axvline(0,c='k',lw=.8);h.axvspan(low,high,color=cols[1],alpha=.3);h.axvline(v,c=cols[1],lw=2,label='Mean and 95% interval');h.set(xlabel='Per-PDB additive − joint MSE (deg²)',ylabel='PDB entries');h.legend();label(h,'E','Paired prediction gains');a[11].axis('off')
save(f,'Figure_1_atlas','Global held-out gain: 0.106 deg² [0.099, 0.113]. Maps share support; additive/joint share color scale.')
# Figure 2
f,a=plt.subplots(2,2,figsize=(10,7.5));a=a.ravel();peptide(a[0],True);a[0].set_ylim(-1.95,3.4);a[0].text(3,-1.3,'ff14SB • vacuum • restrained φ/ψ • relaxed τ',ha='center',fontsize=9);a[0].text(3,-1.7,'α (−60°, −40°)   β (−120°, 130°)   PPII (−75°, 145°)',ha='center',fontsize=8);label(a[0],'A','Isolated peptide model')
for x,y,s in [(-10,-10,'+'),(-10,10,'−'),(10,-10,'−'),(10,10,'+')]:a[1].scatter(x,y,s=500,c='white',edgecolors='black');a[1].text(x,y,s,ha='center',va='center',fontsize=18)
a[1].set(xlim=(-18,18),ylim=(-18,18),xlabel='Δφ (°)',ylabel='Δψ (°)');a[1].text(.5,.03,'C = (τ++ − τ+− − τ−+ + τ−−) / 4',transform=a[1].transAxes,ha='center',fontsize=9);label(a[1],'B','Finite contrast at ±10°')
v=[p['summary']['mixed_finite_contrast_deg'][r] for r in regs];a[2].bar(labs,v,color=cols);a[2].axhline(0,c='k',lw=.8);a[2].set_ylabel('Peptide contrast (°)');label(a[2],'C','Intrinsic mixed dependence')
for r,l,c in zip(regs,labs,cols):
 xx=[float(k)*100 for k in rp['summary']['contrasts_deg'] if float(k)<=.75];yy=[rp['summary']['contrasts_deg'][str(x/100)][r] for x in xx];a[3].plot(xx,yy,'o-',label=l,c=c)
a[3].axhline(0,c='k',lw=.8);a[3].legend();a[3].set(xlabel='Selected repulsion removed (%)',ylabel='Peptide contrast (°)');label(a[3],'D','Targeted repulsion sensitivity')
save(f,'Figure_2_local_model','Numerical precision: Figure S1; selected pairs: Table S1. Curves stop at 75%; full removal has failed endpoints and is withheld.')
# Figure 3
st=zj('183741','matched_contrasts.json');windows=zj('184519','SUMMARY.json')['results'];f,a=plt.subplots(2,3,figsize=(14,8));a=a.ravel()
match_design(a[0]);label(a[0],'A','Matching design')
obs=[ma['regions'][r]['observed_contrast_deg'] for r in regs];mod=[ma['regions'][r]['matched_model_contrast_deg'] for r in regs];x=np.arange(3);a[1].bar(x-.18,obs,.36,color=cols[0],label='Protein');a[1].bar(x+.18,mod,.36,color=cols[1],label='Matched peptide');a[1].set_xticks(x,labs);a[1].axhline(0,c='k',lw=.8);a[1].legend();a[1].set_ylabel('Contrast (°)');label(a[1],'B','Protein versus matched peptide')
for i,r in enumerate(regs):
 q=next(q for q in st if q['stratum']=='ALL' and q['region']==r);v=q['residual_contrast_deg'];lo,hi=q['residual_95CI'];a[2].errorbar(v,i,xerr=[[v-lo],[hi-v]],fmt='o',c=cols[i],capsize=4)
a[2].set_yticks(range(3),labs);a[2].invert_yaxis();a[2].axvline(0,c='k',lw=.8);a[2].set_xlabel('Protein − peptide contrast (°)');label(a[2],'C','Magnitude of the gap')
for axis,r,l in zip(a[3:5],['alpha','ppii'],['α','PPII']):
 rows=[q for q in st if q['region']==r];rows+=[dict(q,stratum='Window ±3°') for q in windows if q['half_width_deg']==3 and q['region']==r]
 for i,q in enumerate(rows):
  v=q['residual_contrast_deg'];lo,hi=q['residual_95CI'];axis.errorbar(v,i,xerr=[[v-lo],[hi-v]],fmt='o',capsize=3,c=cols[0])
 axis.set_yticks(range(len(rows)),[q['stratum'].replace('resolution:','').replace('software:','').replace('ALL','Primary ±5°').replace('<=1.5A','≤1.5 Å').replace('>1.5-2.0A','>1.5–2.0 Å') for q in rows]);axis.invert_yaxis();axis.axvline(0,c='k',lw=.8);axis.set_xlabel('Residual contrast (°)');label(axis,'D' if r=='alpha' else 'E',l+' robustness')
a[5].bar(x-.18,v if False else [p['summary']['mixed_finite_contrast_deg'][r] for r in regs],.36,label='Corner centers',color='#777777');a[5].bar(x+.18,mod,.36,label='Actual sampling',color=cols[1]);a[5].set_xticks(x,labs);a[5].axhline(0,c='k',lw=.8);a[5].legend();a[5].set_ylabel('Peptide contrast (°)');label(a[5],'F','Matching changes the prediction')
save(f,'Figure_3_matched_gap','Conditional PDB bootstrap intervals; post hoc sensitivities. Primary and ±5° are the same analysis, plotted once.')
# SI precision and QC
f,a=plt.subplots(1,3,figsize=(12,4));a[0].bar(labs,[p['summary']['maximum_start_range_deg'][r] for r in regs],color=cols);a[0].set_ylabel('Maximum start-to-start τ range (°)');label(a[0],'A','81 / 81 precision endpoints pass')
a[1].plot([float(k)*100 for k in rp['summary']['passed_by_lambda']],[v for v in rp['summary']['passed_by_lambda'].values()],'o-');a[1].set(xlabel='Repulsion removed (%)',ylabel='Passing endpoints / 81',ylim=(0,85));label(a[1],'B','Full removal fails 3 endpoints')
with zipfile.ZipFile(D/'MATCHED_SAMPLING_RETURN.zip') as z:mm=json.loads(z.read('MANIFEST.json'))
nodes=pd.DataFrame(mm['nodes']);errs=[]
for rr in regs:
 for (op,os),q in nodes[nodes.region==rr].groupby(['offset_phi','offset_psi']):
  gr=q[q.kind=='grid'].pivot(index='i',columns='j',values='tau_deg').values
  for row in q[q.kind=='check'].itertuples():errs.append(dict(region=rr,i=row.i,j=row.j,error_deg=row.tau_deg-gr[row.i:row.i+2,row.j:row.j+2].mean()))
e=pd.DataFrame(errs);assert len(e)==192
for i,rr in enumerate(regs):
 q=e[e.region==rr];a[2].scatter(np.arange(len(q))+i*64,q.error_deg,s=8,color=cols[i],label=labs[i])
a[2].axhline(0,c='k',lw=.7);a[2].set(xlabel='Midpoint check',ylabel='Exact − interpolated τ (°)');a[2].legend();label(a[2],'C','192 midpoint interpolation errors');e.to_csv(O.parent/'midpoint_errors.csv',index=False)
save(f,'Figure_S1_numerical_QC','81/81 precision endpoints and 492/492 grid/check minimizations pass. Midpoint errors test local interpolation, not physical accuracy.')
with zipfile.ZipFile(D/'TAU_REPULSION_RETURN.zip') as z:pd.DataFrame(json.loads(z.read('pairs.json'))).to_csv(O.parent/'Table_S1_repulsion_pairs.csv',index=False)
print(O)

# Recovered paired environment data are a separate cohort.
U=D; env=pd.read_csv(U/'sidechain_switches.csv'); distal=pd.read_csv(U/'protein_median_distal_descriptors.csv'); es=json.loads((U/'SUMMARY.json').read_text())
f,a=plt.subplots(2,2,figsize=(11,8));a=a.ravel()
txt(a[0],'Paired apo / holo audit\n10,928 targets processed\n10,906 audited\n18 side-chain switch sites\nin 15 proteins');label(a[0],'A','Paired environment cohort')
q=env.sort_values('sidechain_present_minus_absent_tau');yy=np.arange(len(q));a[1].scatter(q.sidechain_present_minus_absent_tau,yy,c=np.where(q.sidechain_present_minus_absent_tau>=0,cols[0],cols[1]));a[1].axvline(0,c='k',lw=.8);a[1].set_yticks(yy,[str(v.residue)+' '+str(v.canonical_position)+' / '+str(v.uniprot_id) for v in q.itertuples()],fontsize=7);a[1].set_xlabel('τ contact present − absent (°)');label(a[1],'B','Signed response at 18 sites')
g=es['groups']; names=['mapped_distance_stable','mapped_distance_changed','clean_stable'];a[2].bar(['Stable\nn=7,722','Changed\nn=3,184','Clean stable\nn=19'],[g[n]['median_abs_tau_deg'] for n in names],color=cols);a[2].set_ylabel('Median |Δτ| (°)');label(a[2],'C','Unmatched descriptive groups')
print('DISTAL_COLUMNS',list(distal.columns))
xcol=next(c for c in distal if 'distal' in c and 'median' in c);ycol=next(c for c in distal if 'tau' in c and 'abs' in c);a[3].scatter(distal[xcol],distal[ycol],s=10,alpha=.45,color=cols[0]);a[3].set(xlabel='Protein median distal Cα displacement (Å)',ylabel='Protein median |Δτ| (°)');label(a[3],'D','Association across 462 proteins');a[3].text(.02,.92,'Spearman ρ = 0.420',transform=a[3].transAxes)
save(f,'Figure_S2_paired_environment','Protein-balanced signed median: +0.020° [−0.358, +0.263]. Descriptive associations; no force or density validation.')
