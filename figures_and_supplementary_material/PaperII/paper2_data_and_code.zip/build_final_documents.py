from pathlib import Path
from docx import Document
from docx.shared import Inches,Pt
from scipy.stats import norm
import pandas as pd,numpy as np,re,json,shutil,zipfile
R=Path('/workspace/scratch/af83f9461c6a');O=R/'deliverables/paper2_final';O.mkdir(exist_ok=True)
# Parse current source logs.
rows=[];med={}
angles=[('tau_deg','τ'),('omega_measured_deg','ω'),('angle_N_CA_CB','∠N–Cα–Cβ'),('angle_C_CA_CB','∠C–Cα–Cβ')]
for col,label in angles:
 for line in (R/f'upload/02_{col}.log').read_text().splitlines():
  m=re.match(r'\s*([A-Z]{3})\s+([+-]?\d+\.\d+)\s+(.*)',line)
  if not m:continue
  vals=re.findall(r'([+-]\d+\.\d+)±(\d+\.\d+)',m[3])
  if len(vals)!=4:continue
  med[(label,m[1])]=float(m[2])
  for b,(v,s) in zip(['α','β','PPII','αL'],vals):rows.append([label,m[1],b,float(v),float(s)])
t=pd.DataFrame(rows,columns=['angle','residue','basin','delta_deg','sem_deg']);assert len(t)==288
t['p_value_approx']=2*norm.sf(abs(t.delta_deg/t.sem_deg));t.to_csv(O/'Table_S1.csv',index=False);sig=int((t.p_value_approx<.01).sum())
srows=[];a=None
for line in (R/'upload/08_resolution.log').read_text().splitlines():
 if line.strip().endswith(':') and any(x in line for x in ['tau (','omega (','angle N','angle C']):a=line.strip().rstrip(':')
 m=re.match(r'\s*(\d\.\d)A\s+([\d,]+)\s+(.*)',line)
 if m:
  vals=re.findall(r'([+-]\d+\.\d+)\+/-([\d.]+)',m[3]);assert len(vals)==4
  for b,(v,s) in zip(['α','β','PPII','αL'],vals):srows.append([a,b,float(m[1]),int(m[2].replace(',','')),float(v),float(s)])
st=pd.DataFrame(srows,columns=['angle','basin','cutoff_A','n_structures','delta_deg','sem_deg']);assert len(st)==128;st.to_csv(O/'Table_S2_all_cutoffs.csv',index=False)
r=pd.read_csv(R/'deliverables/paper2_remaining_checks/relax_results_final_pisces.csv');x=111.1-r.tau_pre;a,b=np.polyfit(x,r.d_tau,1);rr=np.corrcoef(x,r.d_tau)[0,1];r['residual']=r.d_tau-(a*x+b);r.to_csv(O/'relaxation_residuals.csv',index=False)
xt=pd.read_csv(R/'deliverables/paper2_remaining_checks/xtal_dtau_pisces.csv');xtd={(v.klass,v.basin):v.dtau for v in xt.itertuples()}
rel=[]
for (k,bs),g in r.groupby(['klass','basin']):
 v=xtd.get((k,bs),np.nan);rel.append([k,bs,len(g),g.d_tau.mean(),g.d_tau.sem(),g.residual.mean(),g.residual.sem(),v,'n/a' if np.isnan(v) else ('match' if np.sign(g.d_tau.mean())==np.sign(v) else 'MISS'),'n/a' if np.isnan(v) else ('match' if np.sign(g.residual.mean())==np.sign(v) else 'MISS')])
rt=pd.DataFrame(rel,columns=['residue','basin','n','raw','raw_sem','residual','residual_sem','xtal','raw_sign','residual_sign']);rt.to_csv(O/'Table_S3.csv',index=False)
d=Document(R/'deliverables/paper2_pisces_working/paper2_pisces_working.docx')
# Use paragraph indices from submission template, which working edits preserved.
def setp(i,s):d.paragraphs[i].clear();d.paragraphs[i].add_run(s)
# Locate by exact text starts, avoiding working inserted note offsets.
for p in list(d.paragraphs):
 if 'PENDING' in p.text or 'pending' in p.text.lower() and ('rerun' in p.text.lower() or 'working' in p.text.lower()):
  p._element.getparent().remove(p._element)
for sec in d.sections:
 for p in sec.header.paragraphs:p.clear()
# Resolve from stable old paragraphs for content replacement.
base=Document(R/'deliverables/paper2_submission/paper2_manuscript.docx'); old={i:p.text for i,p in enumerate(base.paragraphs)}
repl={
16:old[16].replace('1,698,562 residues from 8,292 deposited structures, predominantly determined by X-ray crystallography','1,636,322 residues from 7,938 X-ray structures').replace('approximately 1.7°','approximately 1.5°').replace('0.674','0.669').replace('0.488','0.497').replace('0.219','0.221').replace('0.112','0.115'),
35:old[35].replace('(32 comparisons, all p < 10⁻⁴ except where marked)','(32 comparisons; nominal P-values are reported in the source output)'),
50:f'Across the four observables, 270 of 288 residue–basin combinations agreed with the corresponding pooled basin sign. Approximate two-sided normal tests reconstructed from the printed mean deviations and SEM gave nominal P < 0.01 for {sig} of 288 combinations (Table S1). These residue-level summaries do not account for dependence within protein structures or multiple testing.',
53:'Within the α basin, residue-type mean deviations are weakly linearly correlated with side-chain mass for τ (r = −0.087), ∠N–Cα–Cβ (r = −0.094), and ∠C–Cα–Cβ (r = −0.020); ω gives r = +0.268 (Fig. S2). Class contrasts depend on the observable and basin (Fig. 3A). For example, β-branched residues have a larger positive α-basin Δτ than unbranched residues (+0.867° versus +0.395°), but smaller-magnitude negative Δτ in β (−1.314° versus −1.889°) and PPII (−0.571° versus −0.937°). These patterns support observable-specific associations rather than a universal class ordering.',
54:'Glycine is not a neutral baseline for τ or ω. In the α basin its mean deviations are negative (τ: −0.384°; ω: −1.166°), whereas the other side-chain classes have positive means. In β its τ deviation is −2.424° and its ω deviation is −1.901°. Glycine should therefore be treated separately when interpreting residue-dependent geometry.',
55:'χ₁ rotamer state provides an additional axis of variation (Fig. 3B). For τ, the g⁺–g⁻ contrast is positive in 16 of 17 residue types in α and β and 15 of 17 in PPII; most αL estimates are unavailable because of sparse groups. In α, Ile gives +1.549 ± 0.056° and Val −0.281 ± 0.049°. A separate calculation using 117,414 retained Val residues with both terminal carbon atoms shows that defining the torsion with CG2 instead of standard CG1 changes the α, β and PPII τ contrasts to +1.379 ± 0.038°, +1.218 ± 0.025° and +0.993 ± 0.067°, respectively (Fig. S3). This demonstrates dependence on the torsion definition and group assignments, rather than establishing incorrect atom labeling.',
56:'The ω rotamer contrasts are more heterogeneous: positive contrasts occur for 12 of 17 residue types in α and 11 of 17 in β and PPII. Only one αL residue type satisfies the minimum group-size criterion. These patterns motivate further tests of local steric and electronic contributions.',
57:'Side-chain class and χ₁ rotamer state are associated with geometry in ways that depend on residue type, basin and observable. The results are compatible with geometric coupling at Cα, while the exceptions and sparse αL groups limit universal mechanistic interpretations.',
60:'Local features explain approximately half of τ variance (test R² = 0.4966). Its largest measured residual contrast is associated with strong hydrogen-bond count (0.100 ± 0.012 SD), followed by packing around C (0.093 ± 0.009 SD) and next-residue side-chain contacts (0.085 ± 0.013 SD; Fig. 4B,C). Strong hydrogen-bond count has negligible Pearson correlation with the residual (r = −0.003, P = 0.287); the binned contrast and linear correlation quantify different features of the association.',
61:'∠N–Cα–Cβ is best predicted by local features (test R² = 0.6689). Its largest measured environmental contrast is packing around C (0.100 ± 0.010 SD). These residual contrasts describe associations beyond the measured local predictors.',
62:'The ω model explains a smaller fraction of variance (test R² = 0.1151). The modeled target is unsigned trans-peptide non-planarity, 180° − |ω|, restricted to |ω| >150°. Its largest measured residual contrasts are packing around Cα (0.114 ± 0.009 SD), Cα B-factor (0.110 ± 0.009 SD), and next-residue side-chain contacts (0.109 ± 0.016 SD; Fig. 4B,D). The B-factor residual correlation is r = −0.040. B-factor reflects several sources of crystallographic variation and does not directly measure dynamical rigidity.',
63:'∠C–Cα–Cβ has test R² = 0.2210, with a largest measured environmental contrast of 0.085 ± 0.008 SD for packing around C. Low explanatory power does not itself identify weak energetic constraints.',
67:f'Among 376 saved relaxation results belonging to retained chains, raw sign agreement is 22 of 36 evaluable residue-type × basin groups (61%). A global fit gives Δτ_pred = {a:.6f}(111.1° − τ_pre) + {b:.6f}° (r = {rr:.6f}). Subtracting this fitted component gives agreement in 30 of 36 groups (83%; Table S3). The remaining mismatches are Ala–PPII, His–PPII, Ile–α, Leu–α, Thr–α and Phe–β. This descriptive adjustment does not independently identify a force-field equilibrium or establish energetic validation.',
68:'The resolution diagnostic includes all standard residue types where each observable is defined, including Gly and Pro, and uses the same basin windows. All 16 angle–basin means retain their signs between strict ≤2.0 Å and ≤1.0 Å subsets (7,935 and 324 structures, respectively; Table S2). Magnitudes vary with resolution. Persistence of signs does not exclude refinement-restraint bias or establish force-field-independent energetic preferences.',
70:'For 1,612,919 final-feature residues matched to the bond-length file, the squared Pearson correlation with side-chain lever arm is 0.0587 for τ and 0.0240 for Cα–C bond length (Figure 5). The mean Cα–C bond length differs by 0.0028 Å between the shortest- and longest-lever-arm quartiles (1.5225 versus 1.5253 Å). These statistics describe associations; they do not measure force constants, energetic stiffness or strain partitioning.',
76:'The peptide torsion has low local-model explanatory power and residual associations with packing and crystallographic B-factor. These observations complement previous reports of peptide non-planarity14 and motivate direct tests of proposed electronic mechanisms15–18; the present analysis does not identify their contributions.',
87:'Wei Chen: study design, data acquisition and curation, software, formal analysis, visualization, and manuscript drafting and revision. Xiaohong Lu: research supervision, conceptual guidance, scientific direction, and intellectual input on analyses and manuscript reviewing.',
89:'Supplementary Note S1; Figures S1–S3; Table S1 (signed angle-, residue-, and basin-resolved deviations and approximate nominal tests); Table S2 (resolution-stratified angular deviations); Table S3 (restrained molecular mechanics relaxation comparison).',
117:'Figure 5. Associations of side-chain lever arm with backbone geometry for 1,612,919 residues matched by PDB identifier, chain and residue index to the final feature dataset; 23,403 feature residues lack bond-file rows. (A) τ relative to a fixed 111° baseline. (B) Cα–C length relative to 1.525 Å. These plotting baselines differ from the residue-specific medians used in Figures 2 and 3. (C) Squared Pearson correlations with geometric observables; these do not measure mechanical stiffness. φ and ψ are treated as numerical angular values in this exploratory comparison, so their correlations depend on the angular representation. (D) Cα–C bond-length distributions by lever-arm quartile; the Q4–Q1 mean difference is 0.0028 Å. μ, quartile mean; DOF, geometric degree of freedom.'}
repl[132]=repl[117]
repl[43]=old[43].replace('778 residues from 800 candidates','376 saved residue results belonging to retained PISCES-consistent chains, from a candidate set spanning').replace('spanning spanning','spanning')
# Fix malformed phrase explicitly.
repl[43]='Restrained local molecular mechanics results were available for 376 residues in retained PISCES-consistent chains, spanning 10 residue types and four Ramachandran basins. The OpenMM runner prepares deposited structures with PDBFixer and AMBER ff14SB (amber14-all.xml), frees the target residue from positional restraints, and strongly restrains surrounding atoms. The recorded workflow specifies --k_dih 800, a target φ/ψ restraint strength of 800 kJ mol⁻¹ rad⁻², and no MechLib overlay. Each candidate starts from the same prepared coordinates; no dynamics steps are performed. Raw τ changes and residuals from a global linear adjustment for initial τ are compared with crystal deviation signs (Table S3).'
for p in d.paragraphs:
 for i,s in repl.items():
  # working version may only differ in dataset counts
  if p.text==old[i] or p.text==old[i].replace('1,698,562','1,636,322').replace('8,292','7,938'):
   p.clear();p.add_run(s);break
# Insert method detail after local model paragraph.
for p in d.paragraphs:
 if p.text.startswith('Local contributions were modeled'):
  p.add_run(' For ω, the target is 180° − |ω| for trans peptides with |ω| >150°. Environmental effects are the range of predictor-bin mean residuals divided by residual SD; bootstrap errors use 200 residue-level resamples. Residuals are evaluated over the sampled training and test rows together. The 0.08 SD color threshold is a display threshold, not a significance test.')
# Refresh Table 1 from the dedicated 01b log, preserving SEM convention.
for line in (R/'upload/01b.log').read_text().splitlines():
 m=re.match(r'\s*([A-Z]{3})\s+(\d+\.\d+)\s+(.*)',line)
 if m:
  vals=re.findall(r'([+-]\d+\.\d+)±(\d+\.\d+)',m[3])
  if len(vals)==4:
   for row in d.tables[0].rows:
    if row.cells[0].text.strip()==m[1]:
     for c,v in zip(row.cells,[m[1],m[2]]+[f'{v} ± {s}' for v,s in vals]):c.text=v
# Replace figure images by their positions.
images=['paper2_figure2(1).png','paper2_figure3(1).png','paper2_figure4(2).png','supp_stiffness_hierarchy(1).png']
shapes=list(d.inline_shapes);assert len(shapes)==5
for shape,name in zip(shapes[1:],images):
 rid=shape._inline.graphic.graphicData.pic.blipFill.blip.embed
 d.part.related_parts[rid]._blob=(R/'upload'/name).read_bytes()
# Correct ratio-independent figure dimensions for new aspect ratios.
from PIL import Image
for shape,name in zip(shapes[1:],images):
 w,h=Image.open(R/'upload'/name).size;shape.height=int(shape.width*h/w)
d.save(O/'paper2_manuscript.docx')
# Edit SI prose and replace existing tables in-place.
si=Document(R/'deliverables/paper2_submission/paper2_SI.docx')
sirepl={3:'This supplement documents the structural dataset, use of observed coordinates, side-chain comparisons, resolution stratification and restrained relaxation analyses.',7:'The PISCES acquisition list contains 9,162 chains from 8,887 PDB entries at ≤25% sequence identity, nominal X-ray resolution ≤2.0 Å and crystallographic R-factor ≤0.25. The final analysed set retains 7,836 exact PDB–chain matches (1,618,814 residues) and 102 alternatives with identical complete nonempty SEQRES sequences to selected chains in the same entries (17,508 residues): 7,938 chains and 1,636,322 residues. Sequence equivalence does not imply coordinate identity. The chain audit manifest and selection list are supplied as supporting data.',12:'Figure S1. Residue-centered Δτ in 10° × 10° Ramachandran bins containing at least 30 residues. Left: 18 types excluding Gly and Pro (n = 1,443,900); middle: Gly (n = 118,563); right: Pro (n = 73,859). Positive and negative values are relative to residue-type medians. The main panel has limits ±1.5° and Gly/Pro ±2.25°; the visible color bar applies to the main panel.',13:'Panel-specific display limits are given in the caption.',17:'Figure S2. Side-chain mass descriptor versus α-basin mean residue-centered deviation for 18 residue types excluding Gly and Pro. Each point represents a residue type. Pearson r is −0.087 for τ, +0.268 for ω, −0.094 for ∠N–Cα–Cβ and −0.020 for ∠C–Cα–Cβ. These correlations use 18 residue-type means; the script labels its integer mass descriptor in Da.',20:'Table S1. Signed means and SEM in degrees for four observables, 18 residue types and four basins, transcribed from the four angle-specific rerun logs. Δ is measured relative to the global residue-type median; ω uses circular centering. Rotamer comparisons are separate.',21:f'The accompanying Table_S1.csv contains 288 combinations and approximate two-sided normal P-values from the rounded printed means and SEM; {sig} have nominal P <0.01. Tests are unadjusted for multiple comparisons and within-structure dependence. These are approximate summary-data tests.',34:'Table S2. Resolution-stratified mean deviations and SEM from paper2_08_angle_resolution_stratified.py using the final feature CSV and resolutions.csv. All 1,636,322 rows matched a resolution. Strict ≤2.0 Å and ≤1.0 Å subsets contain 7,935 and 324 structures. Counts refer to the angle-valid input subset, not per-basin residue counts.',35:'All 16 angle–basin means preserve their signs between these cutoffs, while magnitudes vary. All eight cutoffs are supplied in Table_S2_all_cutoffs.csv. This diagnostic uses the same basin windows as the main analysis and includes all standard residue types where each angle is defined, including Gly and Pro. Its pooled means therefore differ from the 18-type main summaries.',36:'Resolution medians are computed once per residue type across matched, angle-valid rows before applying cutoffs. The script uses inclusive basin boundaries and literal ≤ resolution comparisons. Three retained entries have metadata marginally above 2.0 Å: 6NSI (2.000063 Å), 7AOV (2.000016 Å) and 7M3P (2.000019 Å). The nominal ≤2.0 Å PISCES selection therefore has 7,938 entries, while this strict numerical cutoff retains 7,935. The ≤3.5 Å diagnostic is not an acquisition threshold. Persistence does not exclude refinement-restraint bias.',39:'Table S3. The saved relaxation file contains 778 results from 800 candidates. Restricting PDB–chain pairs to exact or sequence-identical PISCES-consistent chains retains 376 results and excludes 402. These were reused without rerunning minimization. Ten residue types and four basins are represented. Gly lacks the 18-type crystal comparator. Sign comparisons require at least five results per group; 36 groups are evaluable, giving raw agreement 22/36 and adjusted agreement 30/36. Candidate residue-level membership in the quality-filtered feature file was not separately established; this comparison is restricted by chain membership.',42:f'An ordinary least-squares line is fitted across all 376 retained results: Δτ_pred = {a:.6f}(111.1° − τ_pre) + {b:.6f}°, with Pearson r = {rr:.6f}. Residual = Δτ − Δτ_pred. SEM uses sample SD/√n. Group signs are compared with the updated 01b crystal means; their printed precision is 0.001°. Because an intercept is fitted, the reference angle does not change residuals. Agreement is descriptive and does not establish independent energetic validation.',43:'Raw and residual changes and crystal deviations are in degrees; parenthesized values are SEM. All groups are supplied in Table_S3.csv and individual residuals in relaxation_residuals.csv.',48:'Groups with fewer than five saved results are reported numerically but excluded from the sign-agreement tally. Gly has no crystal sign comparator. Match and MISS denote agreement or disagreement with the comparator sign.'}
for i,s in sirepl.items():si.paragraphs[i].clear();si.paragraphs[i].add_run(s)
for shape,name in zip(si.inline_shapes,['01a_tau_map(2).png','03_sidechain_scatter.png']):
 rid=shape._inline.graphic.graphicData.pic.blipFill.blip.embed;si.part.related_parts[rid]._blob=(R/'upload'/name).read_bytes();w,h=Image.open(R/'upload'/name).size;shape.height=int(shape.width*h/w)
# Table shapes inspect and adapt existing row cells.
for tab,label in zip(si.tables[:4],[v[1] for v in angles]):
 for row in tab.rows[1:]:
  res=row.cells[0].text.strip()
  if res in t.residue.values:
   g=t[(t.angle==label)&(t.residue==res)]
   vals=[res]+[f'{g[g.basin==bs].iloc[0].delta_deg:+.3f} ({g[g.basin==bs].iloc[0].sem_deg:.3f})' for bs in ['α','β','PPII','αL']]
   for c,v in zip(row.cells,vals):c.text=v
# Replace resolution and relaxation tables entirely with compact rows.
def refill(tab,headers,data):
 for row in list(tab.rows)[1:]:tab._tbl.remove(row._tr)
 for c,v in zip(tab.rows[0].cells,headers):c.text=v
 for vals in data:
  for c,v in zip(tab.add_row().cells,vals):c.text=str(v)
 for row in tab.rows:
  for c in row.cells:
   for p in c.paragraphs:
    p.paragraph_format.space_after=Pt(3)
    for run in p.runs:run.font.size=Pt(8)
resdata=[]
for (ang,bs),g in st.groupby(['angle','basin'],sort=False):
 lo=g[g.cutoff_A==2].iloc[0];hi=g[g.cutoff_A==1].iloc[0];resdata.append([ang,bs,f'{lo.delta_deg:+.3f} ({lo.sem_deg:.3f})',f'{hi.delta_deg:+.3f} ({hi.sem_deg:.3f})','yes'])
refill(si.tables[4],['Angle','Basin','≤2.0 Å','≤1.0 Å','Same sign'],resdata)
rel_data=[[v.residue,v.basin,v.n,f'{v.raw:+.3f} ({v.raw_sem:.3f})',f'{v.residual:+.3f} ({v.residual_sem:.3f})','n/a' if np.isnan(v.xtal) else f'{v.xtal:+.3f}',v.raw_sign,v.residual_sign] for v in rt.itertuples()]
refill(si.tables[5],['Residue','Basin','n','Raw Δτ','Residual','Crystal Δτ','Raw sign','Residual sign'],rel_data[:20]);refill(si.tables[6],['Residue','Basin','n','Raw Δτ','Residual','Crystal Δτ','Raw sign','Residual sign'],rel_data[20:])
si.add_page_break();si.add_heading('Figure S3 Valine torsion definition comparison',level=1);si.add_picture(str(R/'upload/06_val_anomaly.png'),width=Inches(6.8));si.add_paragraph('Figure S3. Val g⁺–g⁻ mean contrasts using N–Cα–Cβ–CG1 (standard) and N–Cα–Cβ–CG2 (alternative). Analysis is restricted to final-feature Val residue keys: 117,414 of 117,438 Val residues have the required atoms and geometry. Error bars are propagated residue-level SEM. Changing the terminal carbon changes rotamer group assignments; this comparison does not establish mislabeled atoms or a universal mechanism. The χ₁ difference is within 15° of ±120° for 99.9% of analysed residues.')
si.save(O/'paper2_SI.docx')
print('S1 nominal significant',sig,'relax slope/intercept',a,b,'tables',[len(v.rows) for v in si.tables])
