from pathlib import Path
from docx import Document
import shutil,zipfile,json,hashlib
R=Path('/workspace/scratch/af83f9461c6a');O=R/'deliverables/paper2_final'
d=Document(O/'paper2_manuscript.docx')
p=d.paragraphs[16]
s=p.text.replace('approximately 1.7°','approximately 1.5°').replace('0.674','0.669').replace('0.488','0.497').replace('0.219','0.221').replace('0.112','0.115');p.clear();p.add_run(s)
# Relevant methods specify diagnostic inclusion explicitly.
for p in d.paragraphs:
 if p.text.startswith('To compare associations across geometric'):pass
 if p.text.startswith('The side-chain lever arm was defined'):
  p.add_run(' Bond lengths were joined to the final feature file using unique PDB identifier, chain and residue-index keys. This comparison contains 1,612,919 matched rows; 23,403 final-feature residues have no bond-file match.')
d.save(O/'paper2_manuscript.docx')
# Build reproducibility archive with final outputs, source logs and scripts.
A=O/'supporting_data_and_code';A.mkdir(exist_ok=True)
for name in ['Table_S1.csv','Table_S2_all_cutoffs.csv','Table_S3.csv','relaxation_residuals.csv']:shutil.copy2(O/name,A/name)
for name in ['01a.log','01b.log','02_tau_deg.log','02_omega_measured_deg.log','02_angle_N_CA_CB.log','02_angle_C_CA_CB.log','03.log','04.log','05.log','07.log','08_resolution.log','04_assembly.log','05_bond_analysis(1).log','06_val_anomaly.log','chain_audit_manifest.csv']:
 shutil.copy2(R/'upload'/name,A/name)
for name in ['features_collector.py','pdb_loader.py','molcore.py','filter_quality.py','download_pdbs.py','paper2_01a_tau_map.py','paper2_01b_tau_by_residue.py','paper2_02_angle_universality.py','paper2_03_sidechain_scatter.py','paper2_04_sidechain_channel.py','paper2_05_rotamer_per_residue.py','paper2_07_residual_regression.py','paper2_08_angle_resolution_stratified.py','paper2_f1_assembly.py','paper2_f2_assembly.py','paper2_F3_assembly_v2.py','mm_local_relax.py','residual_analysis.py','resolutions.csv']:
 for src in [R/'upload'/name,R/'deliverables/paper2_si'/name]:
  if src.exists():shutil.copy2(src,A/name);break
for src in (R/'deliverables/paper2_remaining_checks').iterdir():
 if src.is_file():shutil.copy2(src,A/src.name)
for name in ['cullpdb_pc25.0_res0.0-2.0_len40-10000_R0.25_Xray_d2026_05_14_chains9162','audit_pisces_chains.py']:
 for src in [R/'upload'/name,R/'deliverables/paper2_si'/name]:
  if src.exists():shutil.copy2(src,A/name);break
fig=O/'figures';fig.mkdir(exist_ok=True)
for dst,src in [('Figure_2.png','paper2_figure2(1).png'),('Figure_3.png','paper2_figure3(1).png'),('Figure_4.png','paper2_figure4(2).png'),('Figure_5.png','supp_stiffness_hierarchy(1).png'),('Figure_S1.png','01a_tau_map(2).png'),('Figure_S2.png','03_sidechain_scatter.png'),('Figure_S3.png','06_val_anomaly.png')]:shutil.copy2(R/'upload'/src,fig/dst)
# Keep Figure 1 as embedded in the manuscript and export identical bytes.
rid=d.inline_shapes[0]._inline.graphic.graphicData.pic.blipFill.blip.embed;(fig/'Figure_1.png').write_bytes(d.part.related_parts[rid].blob)
record='''# Paper II verified analysis record\n\nFinal feature input: chain_audit_features_pisces_consistent.csv, 1,636,322 residues, 7,938 chains and entries. Exact matches: 7,836 chains and 1,618,814 residues. Sequence-identical alternatives: 102 chains and 17,508 residues. PISCES nominal X-ray acquisition resolution ≤2.0 Å; strict resolution diagnostic gives 7,935 at ≤2.0 Å and 324 at ≤1.0 Å owing to three metadata values just above 2.0. The diagnostic includes Gly and Pro; main 18-type summaries exclude them.\n\nVerified logs: 01a, 01b, four 02 angles, 03, 04, 05, 06, 07, 08, main figure 4 assembly and matched bond analysis. Main Table 1 uses 01b sample SEM; Table S1 preserves 02 printed SEM. For sparse groups these SEM conventions differ slightly. Table S1 269/288 nominal P<0.01 and 270/288 pooled-sign agreement are different statistics.\n\nMatched bond analysis uses 1,612,919 final-feature residue keys; 23,403 unmatched. The corrected script joins only three bond-length columns, preserving geometry and descriptors from the final feature file. Correlations do not measure stiffness.\n\nVAL: 117,438 final-feature VAL rows; 117,414 extracted with required atoms; standard τ contrasts reproduce 05. Alternative CG2 changes group assignments and does not establish atom-label errors.\n\nRelaxation: saved results restricted by retained chain membership, 376/778 retained. No MM rerun. OLS slope 0.42008119426413776, intercept 0.6047624596919859, r 0.482443. Sign agreement 22/36 raw and 30/36 adjusted. Crystal signs use updated printed 01b means. Relaxation candidate membership in quality-filtered feature rows remains unverified and is disclosed in SI. Original runtime/platform and convergence diagnostics unavailable.\n\nAutomatic mechanistic verdicts in source logs are not scientific conclusions adopted in the manuscript. Local-model split is residue-level; residuals include training and test rows; bootstrap is residue-level; φ/ψ raw numerical Pearson comparisons are exploratory.\n\nThe large feature CSV and PDB cache remain on the author workstation and are not included in this archive. This source package is not a substitute for depositing the final feature CSV for readers.\n'''
(A/'ANALYSIS_RECORD.md').write_text(record)
(O/'SUBMISSION_README.md').write_text('Submit paper2_manuscript.docx and paper2_SI.docx as the article and supplement. Figures are also supplied separately. Review author affiliations, declarations and contact details before submission. The analysis record documents source provenance and known limits. The final feature CSV remains on the author workstation and should be deposited with the final data.\n')
with zipfile.ZipFile(O/'paper2_supporting_data_and_code.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in A.iterdir():z.write(p,p.name)
# Update active documentation copy without dropping unrelated bundle material.
B=R/'deliverables/PBM_ACTIVE_BUNDLE_v4_24'
if B.exists():
 target=B/'artifacts/paper2_pisces_final_20261005';target.mkdir(exist_ok=True)
 shutil.copy2(A/'ANALYSIS_RECORD.md',target/'ANALYSIS_RECORD.md')
 for name in ['paper2_manuscript.docx','paper2_SI.docx','paper2_supporting_data_and_code.zip']:shutil.copy2(O/name,target/name)
 for p in B.glob('*.md'):
  if p.name.upper().startswith(('INDEX','PROJECT_STATUS')):
   p.write_text(p.read_text()+'\n\n## Paper II PISCES final update 2026 10 05\n'+record.split('\n\n',1)[1])
 with zipfile.ZipFile(R/'deliverables/PBM_ACTIVE_BUNDLE_paper2_final.zip','w',zipfile.ZIP_DEFLATED) as z:
  for p in B.rglob('*'):
   if p.is_file():z.write(p,p.relative_to(B))
