"""
paper2_08_angle_resolution_stratified.py — Does the angle signal survive at
high resolution only?
=============================================================================

Reviewer 1's specific request (not a generic "add rigor" ask):

    "it would be valuable to demonstrate that [the reported angular
    deviations] remain robust when progressively restricting the analysis
    to increasingly high-quality structures. A similar issue has previously
    been reported for carbohydrate crystal structures, where systematic
    ring-inversion-related conformational trends disappeared when only the
    highest-quality crystallographic data were considered."

This is deliberately NOT paper2_08_resolution_stratified.py / the
paper3_bond_length_scoping-based script -- that one tests bond LENGTHS
for a different paper. This script re-runs the SAME canonical-region
Delta-angle analysis as paper2_01b/paper2_02 (tau_deg, angle_N_CA_CB,
angle_C_CA_CB, omega_measured_deg), but repeated at a series of
progressively stricter resolution cutoffs, using fetch_resolution.py's
output (resolutions.csv).

If the region means (alpha/beta/PPII/alphaL) hold their sign and roughly
their magnitude as you restrict to only <=1.5A, <=1.2A, <=1.0A structures,
that directly answers the reviewer. If they shrink toward zero or flip
sign as resolution improves (the carbohydrate failure mode), that's a
real problem to report honestly, not paper over.

Usage
-----
    python paper2_08_angle_resolution_stratified.py \\
        --csv features_lj_v3_FINAL_CLEAN.csv \\
        --resolutions resolutions.csv \\
        --out ./figures/paper2/08_resolution_stratified.png

    # if your column names differ from the defaults:
    python paper2_08_angle_resolution_stratified.py \\
        --csv features.csv --resolutions resolutions.csv \\
        --feature_pdb_col pdb --res_pdb_col pdb_id --res_col resolution \\
        --out out.png
"""

import argparse
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path


_REGIONS = {
    'alpha': {'phi': (-80, -40),  'psi': (-60, -20)},
    'beta':  {'phi': (-150, -90), 'psi': (100, 160)},
    'PPII':  {'phi': (-90, -60),  'psi': (120, 160)},
    'alphaL':{'phi': (40, 80),    'psi': (20, 80)},
}
_REGION_ORDER = ['alpha', 'beta', 'PPII', 'alphaL']

# Same four angles as paper2_01b/02/03/04/05, so numbers are directly comparable.
_ANGLES = [
    ('tau_deg',            False, 'tau (N-Ca-C)'),
    ('omega_measured_deg', True,  'omega (peptide)'),
    ('angle_N_CA_CB',      False, 'angle N-Ca-Cb'),
    ('angle_C_CA_CB',      False, 'angle C-Ca-Cb'),
]

# Progressively stricter cutoffs -- "<= X Angstrom", matching the reviewer's
# own phrasing ("progressively restricting ... to increasingly high-quality").
_DEFAULT_CUTOFFS = [3.5, 3.0, 2.5, 2.0, 1.8, 1.5, 1.2, 1.0]


def _circ_median_deg(v):
    v = np.asarray(v, dtype=float)
    rad = np.radians(v)
    mean = np.degrees(np.arctan2(np.mean(np.sin(rad)), np.mean(np.cos(rad))))
    shifted = ((v - mean + 180) % 360) - 180
    return ((np.median(shifted) + mean + 180) % 360) - 180


def _circ_diff(a, b):
    return (a - b + 180) % 360 - 180


def _circ_mean_deg(v):
    rad = np.radians(np.asarray(v, dtype=float))
    return np.degrees(np.arctan2(np.mean(np.sin(rad)), np.mean(np.cos(rad))))


def region_mean_sem(df, region, value_col, circular=False, min_n=30):
    p, q = _REGIONS[region]['phi'], _REGIONS[region]['psi']
    m = (df['phi_deg'].between(p[0], p[1]) & df['psi_deg'].between(q[0], q[1]))
    v = df.loc[m, value_col].values
    n = len(v)
    if n < min_n:
        return float('nan'), float('nan'), n
    if circular:
        mean = _circ_mean_deg(v)
        std = float(np.std(_circ_diff(v, mean)))
    else:
        mean = float(v.mean())
        std = float(v.std())
    return mean, std / np.sqrt(n), n


def prepare_delta(df, angle, circular):
    df = df.dropna(subset=[angle, 'phi_deg', 'psi_deg', 'res_name']).copy()
    if circular:
        medians = df.groupby('res_name')[angle].apply(lambda g: _circ_median_deg(g.values))
        df['delta'] = _circ_diff(df[angle].values, df['res_name'].map(medians).values)
    else:
        medians = df.groupby('res_name')[angle].median()
        df['delta'] = df[angle] - df['res_name'].map(medians)
    return df


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--csv', required=True, help='features CSV (e.g. features_lj_v3_FINAL_CLEAN.csv)')
    ap.add_argument('--resolutions', required=True, help='CSV from fetch_resolution.py')
    ap.add_argument('--feature_pdb_col', default=None,
                     help='PDB id column in --csv (auto-detects pdb_id/pdb/pdbid if omitted)')
    ap.add_argument('--res_pdb_col', default=None,
                     help='PDB id column in --resolutions (auto-detects if omitted)')
    ap.add_argument('--res_col', default=None,
                     help='resolution column in --resolutions (auto-detects resolution/res/res_a if omitted)')
    ap.add_argument('--cutoffs', type=float, nargs='+', default=_DEFAULT_CUTOFFS,
                     help=f'resolution cutoffs in Angstrom, loosest to strictest '
                          f'(default: {_DEFAULT_CUTOFFS})')
    ap.add_argument('--min_n', type=int, default=30,
                     help='minimum residues per region per cutoff to plot/report (default 30)')
    ap.add_argument('--out', default='paper2_08_angle_resolution_stratified.png')
    args = ap.parse_args()

    csv_path = Path(args.csv)
    res_path = Path(args.resolutions)
    if not csv_path.exists():
        print(f"ERROR: {csv_path} not found"); sys.exit(1)
    if not res_path.exists():
        print(f"ERROR: {res_path} not found"); sys.exit(1)

    print(f"Loading {csv_path} ...")
    df = pd.read_csv(csv_path)
    print(f"  {len(df):,} rows")

    print(f"Loading {res_path} ...")
    res_df = pd.read_csv(res_path)
    print(f"  {len(res_df):,} rows, columns: {list(res_df.columns)}")

    # ── Auto-detect / validate join and resolution columns ───────────────────
    def _pick(cols, candidates, arg_val, label):
        if arg_val:
            if arg_val not in cols:
                print(f"ERROR: --{label} '{arg_val}' not in columns: {cols}")
                sys.exit(1)
            return arg_val
        for c in candidates:
            if c in cols:
                return c
        print(f"ERROR: could not auto-detect {label} column. "
              f"Available columns: {cols}\nPass it explicitly with --{label.replace(' ', '_')}.")
        sys.exit(1)

    feat_pdb_col = _pick(list(df.columns), ['pdb_id', 'pdb', 'pdbid', 'PDB_ID', 'PDB'],
                          args.feature_pdb_col, 'feature_pdb_col')
    res_pdb_col = _pick(list(res_df.columns), ['pdb_id', 'pdb', 'pdbid', 'PDB_ID', 'PDB'],
                         args.res_pdb_col, 'res_pdb_col')
    res_col = _pick(list(res_df.columns), ['resolution', 'res', 'res_a', 'resolution_a'],
                     args.res_col, 'res_col')

    print(f"\nJoining on features['{feat_pdb_col}'] == resolutions['{res_pdb_col}'], "
          f"resolution column = '{res_col}'")

    # Normalize case/whitespace on the join key both sides (common source of
    # silent join failures: "1ABC" vs "1abc" vs "1abc.pdb")
    df['_pdb_key'] = df[feat_pdb_col].astype(str).str.strip().str.lower().str.replace('.pdb', '', regex=False)
    res_df['_pdb_key'] = res_df[res_pdb_col].astype(str).str.strip().str.lower().str.replace('.pdb', '', regex=False)
    res_lookup = res_df.drop_duplicates('_pdb_key').set_index('_pdb_key')[res_col]

    df['resolution'] = df['_pdb_key'].map(res_lookup)
    n_matched = df['resolution'].notna().sum()
    n_total = len(df)
    print(f"  matched resolution for {n_matched:,}/{n_total:,} rows "
          f"({100*n_matched/n_total:.1f}%)")
    if n_matched / n_total < 0.5:
        print("  WARNING: less than half of rows matched a resolution. Check "
              "--feature_pdb_col/--res_pdb_col, and whether the two files use "
              "the same PDB ID format (e.g. one has chain suffixes, one doesn't).")

    df = df.dropna(subset=['resolution'])

    cutoffs = sorted(args.cutoffs, reverse=True)  # loosest first

    # ── Compute Delta per angle x region x cutoff ────────────────────────────
    print("\n" + "=" * 100)
    print("Delta per canonical region, at each resolution cutoff (<=X Angstrom)")
    print("=" * 100)

    results = {}  # (angle_label, region) -> list of (cutoff, n_pdbs, n_residues, mean, sem)
    for col, circ, label in _ANGLES:
        d_all = prepare_delta(df, col, circ)
        print(f"\n  {label}:")
        header = f"    {'cutoff':>7}  {'n_pdb':>7}  " + '  '.join(
            f"{r:>16}" for r in _REGION_ORDER)
        print(header)
        for cutoff in cutoffs:
            sub = d_all[d_all['resolution'] <= cutoff]
            n_pdb = sub[feat_pdb_col].nunique()
            line = f"    {cutoff:>6.1f}A  {n_pdb:>7,}  "
            for reg in _REGION_ORDER:
                mean, sem, n = region_mean_sem(sub, reg, 'delta', circular=circ,
                                                min_n=args.min_n)
                results.setdefault((label, reg), []).append((cutoff, n_pdb, n, mean, sem))
                if n < args.min_n:
                    line += f"{'n='+str(n):>16}  "
                else:
                    line += f"{mean:+7.3f}+/-{sem:.3f}".rjust(16) + "  "
            print(line)

    # ── Robustness verdict: does sign/magnitude hold as cutoff tightens? ─────
    print("\n" + "=" * 100)
    print("ROBUSTNESS VERDICT (comparing loosest vs strictest cutoff with n >= min_n)")
    print("=" * 100)
    for col, circ, label in _ANGLES:
        for reg in _REGION_ORDER:
            series = results.get((label, reg), [])
            valid = [(c, n, m, s) for c, npdb, n, m, s in series if n >= args.min_n]
            if len(valid) < 2:
                print(f"  {label:<16} {reg:<8}: insufficient data at enough cutoffs to assess")
                continue
            loosest = valid[0]   # cutoffs sorted loosest-first
            strictest = valid[-1]
            c0, n0, m0, s0 = loosest
            c1, n1, m1, s1 = strictest
            same_sign = np.sign(m0) == np.sign(m1)
            # Positive change_pct = effect GREW at the strict cutoff (good --
            # opposite of the carbohydrate failure mode); negative = SHRANK
            # toward zero (the actual concern Reviewer 1 raised).
            change_pct = 100 * (abs(m1) / abs(m0) - 1) if m0 != 0 else float('nan')
            if not same_sign:
                verdict = "SIGN FLIP -- investigate"
            elif change_pct <= -40:
                verdict = "SHRANK TOWARD ZERO -- possible resolution artifact"
            elif change_pct >= 40:
                verdict = "STRENGTHENED at high resolution"
            else:
                verdict = "ROBUST (stable magnitude)"
            print(f"  {label:<16} {reg:<8}: <= {c0:.1f}A (n={n0:,}) Delta={m0:+.3f}  ->  "
                  f"<= {c1:.1f}A (n={n1:,}) Delta={m1:+.3f}  ({change_pct:+.0f}%)   [{verdict}]")

    # ── Figure: one panel per angle, Delta vs cutoff, one line per region ────
    print(f"\nGenerating {args.out} ...")
    fig, axes = plt.subplots(2, 2, figsize=(13, 10))
    axes = axes.flatten()
    colors = {'alpha': '#c0392b', 'beta': '#2a5d9f', 'PPII': '#5aa369', 'alphaL': '#d9a05b'}

    for k, (col, circ, label) in enumerate(_ANGLES):
        ax = axes[k]
        for reg in _REGION_ORDER:
            series = results.get((label, reg), [])
            xs = [c for c, npdb, n, m, s in series if n >= args.min_n]
            ys = [m for c, npdb, n, m, s in series if n >= args.min_n]
            es = [s for c, npdb, n, m, s in series if n >= args.min_n]
            if not xs:
                continue
            ax.errorbar(xs, ys, yerr=es, marker='o', ms=5, capsize=3,
                        color=colors[reg], label=reg)
        ax.axhline(0, color='k', lw=0.5, alpha=0.4)
        ax.invert_xaxis()  # loosest (large A) on left -> strictest (small A) on right
        ax.set_xlabel('resolution cutoff (<= Angstrom)')
        ax.set_ylabel('Delta (deg)  [vs residue-type median]')
        ax.set_title(label, fontsize=12)
        ax.grid(True, alpha=0.25)
        if k == 0:
            ax.legend(fontsize=9, loc='best')

    plt.suptitle('Angle deformation vs resolution cutoff\n'
                 '(flat lines = robust to resolution; lines converging to 0 as '
                 'cutoff tightens = resolution artifact)',
                 fontsize=12, y=1.01)
    plt.tight_layout()
    plt.savefig(args.out, dpi=200, bbox_inches='tight')
    print(f"Figure saved: {args.out}")


if __name__ == '__main__':
    main()
