#!/usr/bin/env python3
"""
audit_pisces_chains.py - why do analysed chains differ from PISCES selections?

Cause (from the code): download_pdbs.py keeps only the PDB ID and discards the
PISCES chain; features_collector.py calls load_structure(path) with no chain_id,
so pdb_loader._first_protein_chain() takes the FIRST protein chain in the file.
When PISCES selected B (or later), a different chain was analysed.

This script classifies every analysed (pdb_id, chain):
  exact         - analysed chain == PISCES chain
  same_seq      - different chain letter, identical SEQRES to the PISCES chain
                  (homo-oligomer copy: nonredundancy preserved)
  diff_seq      - different chain, different sequence (may violate <=25% identity)
  not_in_pisces - PDB entry absent from the PISCES list
and writes a filtered feature CSV keeping exact + same_seq only.

Usage:
  python audit_pisces_chains.py \
     --pisces cullpdb_pc25.0_res0.0-2.0_len40-10000_R0.25_Xray_d2026_05_14_chains9162 \
     --features protein-backbone-mechanics/features_lj_v3_FINAL_CLEAN.csv \
     --pdb_dir pdb_cache --out_prefix chain_audit
"""
import argparse
from collections import defaultdict
from pathlib import Path
import pandas as pd


def read_pisces(path):
    sel = defaultdict(set)                      # PDBID -> {chains}
    for line in Path(path).read_text().splitlines():
        p = line.split()
        if not p or p[0].lower().startswith(('pdbid', 'pdbchain')):
            continue
        e = p[0]
        pdb, ch = (e.split('_', 1) if '_' in e else (e[:4], e[4:]))
        sel[pdb.upper()].add(ch)
    return sel


def seqres(pdb_file):
    s = defaultdict(list)
    with open(pdb_file, errors='ignore') as f:
        for line in f:
            if line.startswith('SEQRES'):
                s[line[11]].extend(line[19:].split())
            elif line.startswith('ATOM'):
                break
    return {k: tuple(v) for k, v in s.items()}


def find_pdb(pdb_dir, pid):
    for name in (pid.lower(), pid.upper(), pid):
        p = Path(pdb_dir) / f'{name}.pdb'
        if p.exists():
            return p
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--pisces', required=True)
    ap.add_argument('--features', required=True)
    ap.add_argument('--pdb_dir', required=True)
    ap.add_argument('--out_prefix', default='chain_audit')
    a = ap.parse_args()

    sel = read_pisces(a.pisces)
    print(f'PISCES: {sum(map(len, sel.values())):,} chains in {len(sel):,} entries')

    feat = pd.read_csv(a.features, low_memory=False)
    feat['pdb_id'] = feat['pdb_id'].astype(str).str.upper()
    feat['chain'] = feat['chain'].astype(str)
    pairs = feat.groupby(['pdb_id', 'chain']).size().reset_index(name='n_res')
    print(f'Features: {len(feat):,} residues, {len(pairs):,} (pdb, chain) pairs, '
          f'{pairs.pdb_id.nunique():,} entries')

    rows = []
    for pid, ch, n in pairs.itertuples(index=False):
        pis = sel.get(pid)
        if pis is None:
            cls, note = 'not_in_pisces', ''
        elif ch in pis:
            cls, note = 'exact', ''
        else:
            f = find_pdb(a.pdb_dir, pid)
            sr = seqres(f) if f else {}
            mine = sr.get(ch)
            same = [c for c in pis if mine and sr.get(c) == mine]
            if f is None or not sr:
                cls, note = 'diff_seq', 'no SEQRES/pdb file; treated as unverified'
            else:
                cls = 'same_seq' if same else 'diff_seq'
                note = f"PISCES={','.join(sorted(pis))}"
        rows.append(dict(pdb_id=pid, chain=ch, n_res=n, cls=cls, note=note))

    aud = pd.DataFrame(rows)
    aud.to_csv(f'{a.out_prefix}_manifest.csv', index=False)
    print('\nClassification (chains / residues):')
    print(aud.groupby('cls').agg(chains=('pdb_id', 'size'), residues=('n_res', 'sum')))
    print('not_in_pisces:', ', '.join(aud.loc[aud.cls == 'not_in_pisces', 'pdb_id']))

    keep = aud[aud.cls.isin(['exact', 'same_seq'])][['pdb_id', 'chain']]
    sub = feat.merge(keep, on=['pdb_id', 'chain'])
    out = f'{a.out_prefix}_features_pisces_consistent.csv'
    sub.to_csv(out, index=False)
    print(f'\nKept exact+same_seq: {len(sub):,} residues, {keep.pdb_id.nunique():,} entries -> {out}')


if __name__ == '__main__':
    main()
